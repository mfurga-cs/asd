
from zad1testy import runtests



def jak_dojade(G, P, n, a, b):
    # tu prosze wpisac wlasna implementacje
    return None

        

runtests( jak_dojade ) 
