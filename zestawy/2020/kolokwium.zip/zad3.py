from zad3testy import runtests



def longest_incomplete( A, k ):
    # tu prosze wpisac wlasna implementacje
    return 0



runtests( longest_incomplete ) 
