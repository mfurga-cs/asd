# Hubert Giza
# algorytm polega na tym, ze przesuwamy wszystkie elementy tablicy, ktore zostaly przesuniete w
# skutek kolizji, w lewo
# a zatem: wyszukuje on wolny Node, ktory lezy miedzy przydzielona pozycja elementu (wynikajaca
# z hashowania klucza), a aktualnaie sprawdzana pozycja
# w ten sposob kazdy element moze zostac osiagniety, poniewaz bedzie lezec na pozycji
# przydzielonej przez funkcje haszujaca albo w przeciwnym wypadku: miedzy nim a owa pozycja
# wszystkie pola sa taken

# szacowana zlozonosc to O(N), bo zalezy to od liczby kolizji. jezeli liczba kolizji na element jest stala, to zlozonosc bedzie liniowa

class Node:
    def __init__(self, key = None, taken = False):
        self.key = key
        self.taken = taken
        
    def __str__(self):
        if not self.taken:
            print('pusty')
        else:
            print('klucz: ', self.key)


def h(key):
    v = int('0b10101010', 2)
    for l in key:
        v ^= ord(l) % 255
    
    return v % N


N=11
hash_tab = [Node() for i in range(N)]


def recover(tab):
    N = len(tab)

    for x in range(N):

        if h(tab[x].key) != x:  # znaleziony przesuniety element
            i = h(tab[x].key)

            while (i != x and tab[i].taken):  # szukamy wolnego pola
                i = (i + 1) % N

            if not tab[i].taken:  # jezeli sie da, to wstawiamy go na te miejsce
                tab[i], tab[x] = tab[x], tab[i]
