#Hubert Giza
#algorytm jest brzydki. Bierzemy kazdy przedzial z listy. Przyrownujemy konce tego przedzialu z
#kazdym wczesniejszym. Jezeli sie da, to rozszerzamy aktualnie rozwazany przedzial. Po
#porownaniach, przechodzimy po tablicy jeszcze raz i obliczamy maksymalna dlugosc odcinka.
#Nastepnie przechodzimy do nastepnego przedzialu w liscie.
#Zlozonosc obliczeniowa to oczywiscie O(n^2) bo mamy tutaj dwie zagniezdzone funkcje for, ktore
#ida po wszystkich elementach

from inttree import *

def intervals(I):
    max = 0
    res = []
    for i in range(len(I)):
        for k in range(i):
            if I[i][0] <= I[k][0] and I[k][0] <= I[i][1] <= I[k][1]:
                x, y = I[i][0], I[k][1]
                I.pop(i)
                I.insert(i, (x, y))

            elif I[k][0] <= I[i][0] <= I[k][1] and I[i][1] >= I[k][1]:
                # I[i][0] = I[k][0]
                x, y = I[k][0], I[i][1]
                I.pop(i)
                I.insert(i, (x, y))

        for k in range(i + 1):
            tmp = I[k][1] - I[k][0]
            if tmp > max:
                max = tmp
        res.append(max)
    return res

run_tests(intervals)





